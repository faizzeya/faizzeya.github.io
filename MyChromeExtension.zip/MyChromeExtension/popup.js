document.getElementById('changeColorBtn').addEventListener('click', async () => {
  // Choose a random color
  const color = '#' + Math.floor(Math.random()*16777215).toString(16);
  
  // Inject the script into the active tab
  try {
    await chrome.scripting.executeScript({
      target: { tabId: (await chrome.tabs.query({active: true, currentWindow: true}))[0].id },
      func: (newColor) => {
        document.body.style.backgroundColor = newColor;
      },
      args: [color]
    });
  } catch (error) {
    console.error('Failed to change color:', error);
  }
});
